/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.reservation.management.system;

/**
 *
 * @author Eng. Abdelrahman
 */
public class DeluxeRoom extends Room {
    public DeluxeRoom() {
        super("Deluxe", 2, 300.0); // قيم افتراضية
    }

    public String getDetails() {
        return "Deluxe Room with premium facilities.";
    }
}