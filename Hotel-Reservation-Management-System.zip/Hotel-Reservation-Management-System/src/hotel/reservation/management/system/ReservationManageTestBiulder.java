package hotel.reservation.management.system;

import hotel.reservation.management.system.DatabaseConnection;
import hotel.reservation.management.system.Reservation;
import hotel.reservation.management.system.Room;
import java.sql.*;
import java.util.Random;

/**
 * ReservationManageTestBiulder: Singleton class to manage reservations and guest information.
 */
public class ReservationManageTestBiulder {
    // Singleton instance
    private static ReservationManageTestBiulder instance;

    // Private constructor to prevent instantiation
    private ReservationManageTestBiulder() {}

    // Method to get the singleton instance
    public static synchronized ReservationManageTestBiulder getInstance() {
        if (instance == null) {
            instance = new ReservationManageTestBiulder();
        }
        return instance;
    }
    // Funtion adds room if it does not exist.
    public int addRoomToDatabaseIfNotExist(Room room) {
        return addRoomToDatabaseIfNotExist(room.getType(), room.getCapacity(), room.getPricePerNight());
    }
    // Function to add a room if it does not exist
    public int addRoomToDatabaseIfNotExist(String roomType, int roomCapacity, double pricePerNight) {
        int roomNumber = -1;
        String checkQuery = "SELECT RoomNumber FROM RoomsInformation WHERE Type = ? AND Capacity = ? AND PricePerNight = ?";
        String insertQuery = "INSERT INTO RoomsInformation (RoomNumber, Type, Capacity, PricePerNight, RoomStates) VALUES (?, ?, ?, ?, 'Available')";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
             PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {

            // Check if the room already exists
            checkStmt.setString(1, roomType);
            checkStmt.setInt(2, roomCapacity);
            checkStmt.setDouble(3, pricePerNight);
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("RoomNumber"); // Room already exists
                }
            }

            // Generate a unique room number
            Random random = new Random();
            boolean isUnique = false;
            while (!isUnique) {
                roomNumber = random.nextInt(1000) + 1; // Generate a random number
                isUnique = checkRoomNumberUnique(conn, roomNumber);
            }

            // Insert the new room
            insertStmt.setInt(1, roomNumber);
            insertStmt.setString(2, roomType);
            insertStmt.setInt(3, roomCapacity);
            insertStmt.setDouble(4, pricePerNight);
            insertStmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Return -1 if an error occurs
        }
        return roomNumber; // Return the new room number
    }

    // Helper function to check if a room number is unique
    private boolean checkRoomNumberUnique(Connection conn, int roomNumber) throws SQLException {
        String query = "SELECT COUNT(*) FROM RoomsInformation WHERE RoomNumber = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, roomNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() && rs.getInt(1) == 0;
            }
        }
    }

    // Method to create a reservation
    public boolean createReservation(Reservation reservation) {
        try (Connection conn = DatabaseConnection.getInstance().getConnection()) {
            conn.setAutoCommit(false); // Enable transaction mode

            // Insert data into the Guests table
            String guestQuery = "INSERT INTO Guests ("
                    + "GuestName, GuestPhone, GuestEmail, GuestAddress, GuestCity, GuestNationality, PassportNumber, GuestType, RoomNumber, CheckInDate, CheckOutDate, NumberOfDaysOfStayInRoom, Fees)"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmtGuest = conn.prepareStatement(guestQuery)) {
                stmtGuest.setString(1, reservation.getGuestName());
                stmtGuest.setString(2, reservation.getGuestPhone());
                stmtGuest.setString(3, reservation.getGuestEmail());
                stmtGuest.setString(4, reservation.getGuestAddress());
                stmtGuest.setString(5, reservation.getGuestCity());
                stmtGuest.setString(6, reservation.getGuestNationality());
                stmtGuest.setString(7, reservation.getPassportNumber());
                stmtGuest.setString(8, reservation.getGuestType());
                stmtGuest.setInt(9, reservation.getRoomNumber());
                stmtGuest.setDate(10, reservation.getCheckInDate());
                stmtGuest.setDate(11, reservation.getCheckOutDate());
                stmtGuest.setInt(12, reservation.getNumberOfNights());
                stmtGuest.setDouble(13, reservation.getFees());
                stmtGuest.executeUpdate();
            }

            // Insert data into the Reservations table
            String reservationQuery = "INSERT INTO Reservations ("
                    + "RoomNumber, CheckInDate, CheckOutDate, ReservationDate, NumberOfNights, TotalPrice) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmtReservation = conn.prepareStatement(reservationQuery)) {
                stmtReservation.setInt(1, reservation.getRoomNumber());
                stmtReservation.setDate(2, reservation.getCheckInDate());
                stmtReservation.setDate(3, reservation.getCheckOutDate());
                stmtReservation.setDate(4, reservation.getReservationDate());
                stmtReservation.setInt(5, reservation.getNumberOfNights());
                stmtReservation.setDouble(6, reservation.getFees());
                stmtReservation.executeUpdate();
            }

            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false if an error occurs
        }
    }
}
