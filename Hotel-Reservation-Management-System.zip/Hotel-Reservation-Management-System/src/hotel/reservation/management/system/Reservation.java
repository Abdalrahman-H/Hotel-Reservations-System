/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.reservation.management.system;

/**
 *
 * @author Eng. Abdelrahman
 */
public class Reservation {
    private String guestName;
    private String guestPhone;
    private String guestEmail;
    private String guestAddress;
    private String guestCity;
    private String guestNationality;
    private String passportNumber;
    private String guestType;
    private int roomNumber;
    private String roomType;
    private int roomCapacity;
    private java.sql.Date checkInDate;
    private java.sql.Date checkOutDate;
    private java.sql.Date reservationDate;
    private int numberOfNights;
    private double fees;

    private Reservation(Builder builder) {
        this.guestName = builder.guestName;
        this.guestPhone = builder.guestPhone;
        this.guestEmail = builder.guestEmail;
        this.guestAddress = builder.guestAddress;
        this.guestCity = builder.guestCity;
        this.guestNationality = builder.guestNationality;
        this.passportNumber = builder.passportNumber;
        this.guestType = builder.guestType;
        this.roomNumber = builder.roomNumber;
        this.roomType = builder.roomType;
        this.roomCapacity = builder.roomCapacity;
        this.checkInDate = builder.checkInDate;
        this.checkOutDate = builder.checkOutDate;
        this.reservationDate = builder.reservationDate;
        this.numberOfNights = builder.numberOfNights;
        this.fees = builder.fees;
    }

    public static class Builder {
        private String guestName;
        private String guestPhone;
        private String guestEmail;
        private String guestAddress;
        private String guestCity;
        private String guestNationality;
        private String passportNumber;
        private String guestType;
        private int roomNumber;
        private String roomType;
        private int roomCapacity;
        private java.sql.Date checkInDate;
        private java.sql.Date checkOutDate;
        private java.sql.Date reservationDate;
        private int numberOfNights;
        private double fees;

        public Builder setGuestName(String guestName) {
            this.guestName = guestName;
            return this;
        }

        public Builder setGuestPhone(String guestPhone) {
            this.guestPhone = guestPhone;
            return this;
        }

        public Builder setGuestEmail(String guestEmail) {
            this.guestEmail = guestEmail;
            return this;
        }

        public Builder setGuestAddress(String guestAddress) {
            this.guestAddress = guestAddress;
            return this;
        }

        public Builder setGuestCity(String guestCity) {
            this.guestCity = guestCity;
            return this;
        }

        public Builder setGuestNationality(String guestNationality) {
            this.guestNationality = guestNationality;
            return this;
        }

        public Builder setPassportNumber(String passportNumber) {
            this.passportNumber = passportNumber;
            return this;
        }

        public Builder setGuestType(String guestType) {
            this.guestType = guestType;
            return this;
        }

        public Builder setRoomNumber(int roomNumber) {
            this.roomNumber = roomNumber;
            return this;
        }

        public Builder setRoomType(String roomType) {
            this.roomType = roomType;
            return this;
        }

        public Builder setRoomCapacity(int roomCapacity) {
            this.roomCapacity = roomCapacity;
            return this;
        }

        public Builder setCheckInDate(java.sql.Date checkInDate) {
            this.checkInDate = checkInDate;
            return this;
        }

        public Builder setCheckOutDate(java.sql.Date checkOutDate) {
            this.checkOutDate = checkOutDate;
            return this;
        }

        public Builder setReservationDate(java.sql.Date reservationDate) {
            this.reservationDate = reservationDate;
            return this;
        }

        public Builder setNumberOfNights(int numberOfNights) {
            this.numberOfNights = numberOfNights;
            return this;
        }

        public Builder setFees(double fees) {
            this.fees = fees;
            return this;
        }

        public Reservation build() {
            return new Reservation(this);
        }
    }
    public String getGuestName() {
    return guestName;
}
    public String getGuestPhone() {
        return guestPhone;
    }

    public String getGuestEmail() {
        return guestEmail;
    }

    public String getGuestAddress() {
        return guestAddress;
    }

    public String getGuestCity() {
        return guestCity;
    }

    public String getGuestNationality() {
        return guestNationality;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public String getGuestType() {
        return guestType;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public String getRoomType() {
        return roomType;
    }

    public int getRoomCapacity() {
        return roomCapacity;
    }

    public java.sql.Date getCheckInDate() {
        return checkInDate;
    }

    public java.sql.Date getCheckOutDate() {
        return checkOutDate;
    }

    public java.sql.Date getReservationDate() {
        return reservationDate;
    }

    public int getNumberOfNights() {
        return numberOfNights;
    }

    public double getFees() {
        return fees;
    }

}
