package hotel.reservation.management.system;

import java.sql.*;
import java.util.*;

/**
 * ReservationManager: Singleton class to manage reservations and guest information.
 */

public class ReservationManager {
    // Singleton instance
    private static ReservationManager instance;
    // Private constructor to prevent instantiation
    private ReservationManager() {
        
    }
    // Method to get the singleton instance
    public static ReservationManager getInstance() {
        if (instance == null) {
            instance = new ReservationManager();
        }
        return instance;
    }
    
    // Funtion adds room if it does not exist.
    public int addRoomToDatabaseIfNotExist(Room room) {
        return addRoomToDatabaseIfNotExist(room.getType(), room.getCapacity(), room.getPricePerNight());
    }
    // A function that adds the room if it does not exist ( takes the room details as separate parameters)
    public int addRoomToDatabaseIfNotExist(String roomType, int roomCapacity, double pricePerNight) {
    int roomNumber = -1;
    String checkQuery = "SELECT RoomNumber FROM RoomsInformation WHERE Type = ? AND Capacity = ? AND PricePerNight = ?";
    String insertQuery = "INSERT INTO RoomsInformation (RoomNumber, Type, Capacity, PricePerNight, RoomStates) VALUES (?, ?, ?, ?, 'Available')";

    try (Connection conn = DatabaseConnection.getInstance().getConnection();
         PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
         PreparedStatement insertStmt = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS)) {

        // Check if the room already exists
        checkStmt.setString(1, roomType);
        checkStmt.setInt(2, roomCapacity);
        checkStmt.setDouble(3, pricePerNight);
        try (ResultSet rs = checkStmt.executeQuery()) {
            if (rs.next()) {
                // Return the room number if the room already exists
                return rs.getInt("RoomNumber");
            }
        }
        // Add it to the database if the room does not exist
        Random random = new Random();
        boolean isUnique = false;

        while (!isUnique) {
            // Generate a random room number
            roomNumber = random.nextInt(1000) + 1; 
            // Verify that the number is unique
            isUnique = checkRoomNumberUnique(conn, roomNumber); 
        }
        // Set room number
        insertStmt.setInt(1, roomNumber); 
        insertStmt.setString(2, roomType);
        insertStmt.setInt(3, roomCapacity);
        insertStmt.setDouble(4, pricePerNight);

        int affectedRows = insertStmt.executeUpdate();
        if (affectedRows > 0) {
            // Return the room number if the addition is successful
            return roomNumber; 
        }

        } catch (SQLException e) {
        }
          // IF the operation fails, it returns -1
        return -1; 
}
    ////  *************   Not currently in use    ************** ///
    /**
     * 
     * //// Function to get the price per night from the database
//    public double fetchRoomPrice(int roomNumbers) {
//        double pricePerNight = 0.0;
//
//        // استعلام SQL لجلب السعر بناءً على رقم الغرفة
//        String sql = "SELECT PricePerNight FROM roominformation WHERE RoomNumber = ?";
//        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
//            // تعيين رقم الغرفة في الاستعلام
//            stmt.setInt(1, roomNumbers);
//
//            // تنفيذ الاستعلام
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (rs.next()) {
//                    // استخراج السعر من النتيجة
//                    pricePerNight = rs.getDouble("PricePerNight");
//                }
//            }
//        } catch (SQLException ex) {
//        }
//
//        return pricePerNight;
//    }
//    // دالة تضيف الغرفة إذا لم تكن موجودة (تأخذ كائن Room كمعامل)
//public int addRoomToDatabaseIfNotExist(Room room) {
//    return addRoomToDatabaseIfNotExist(room.getType(), room.getCapacity(), room.getPricePerNight());
//}
//    // Method to add a room to the database with a unique random RoomNumber
//    public int addRoomToDatabaseIfNotExist(Room room ,String roomType, int roomCapacity, double pricePerNight) {
//    String checkQuery = "SELECT RoomNumber FROM RoomsInformation WHERE Type = ? AND Capacity = ? AND PricePerNight = ?";
//    String insertQuery = "INSERT INTO RoomsInformation (RoomNumber, Type, Capacity, PricePerNight, RoomStates) VALUES (?, ?, ?, ?, 'Available')";
//    int roomNumber = -1;
//
//    try (Connection conn = DatabaseConnection.getInstance().getConnection();
//         PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
//         PreparedStatement insertStmt = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS)) {
//
//        // تحقق مما إذا كانت الغرفة موجودة
//        checkStmt.setString(1, room.getType());
//        checkStmt.setInt(2, room.getCapacity());
//        checkStmt.setDouble(3, room.getPricePerNight());
//        try (ResultSet rs = checkStmt.executeQuery()) {
//            if (rs.next()) {
//                // إذا كانت الغرفة موجودة، إرجاع رقم الغرفة
//                return rs.getInt("RoomNumber");
//            }
//        }
//
//        // إذا لم تكن الغرفة موجودة، أضفها
//        Random random = new Random();
//        boolean isUnique = false;
//
//        while (!isUnique) {
//            roomNumber = random.nextInt(1000) + 1; // إنشاء رقم غرفة عشوائي
//            isUnique = checkRoomNumberUnique(conn, roomNumber); // التحقق من تفرد الرقم
//        }
//
//        insertStmt.setInt(1, roomNumber); // تعيين رقم الغرفة
//        insertStmt.setString(2, room.getType());
//        insertStmt.setInt(3, room.getCapacity());
//        insertStmt.setDouble(4, room.getPricePerNight());
//
//        int affectedRows = insertStmt.executeUpdate();
//        if (affectedRows > 0) {
//            return roomNumber; // إرجاع رقم الغرفة بعد الإضافة
//        }
//
//    } catch (SQLException e) {
//        e.printStackTrace();
//    }
//
//    return -1; // إرجاع -1 إذا فشلت العملية
//}
     * 
     */

    // Check if room number is unique in the RoomsInformation table
    private boolean checkRoomNumberUnique(Connection conn, int roomNumber) throws SQLException {
        String query = "SELECT COUNT(*) FROM RoomsInformation WHERE RoomNumber = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, roomNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) == 0; // If room number not found, it's unique
                }
            }
        }
        return false;
    }

    public boolean createReservation(
        String guestName,
        String guestPhone,
        String guestEmail,
        String guestAddress,
        String guestCity,
        String guestNationality,
        String passportNumber,
        String guestType,
        int roomNumber,
        String roomType,
        int roomCapacity,
        java.sql.Date checkInDate,
        java.sql.Date checkOutDate,
        java.sql.Date reservationDate,
        int numberOfNights,
        double fees
    ) {
        Connection conn = null;
        PreparedStatement stmtGuest = null;
        PreparedStatement stmtRoom = null;
        PreparedStatement stmtReservation = null;

        try {
            // Create Room Using Factory and add it to the database
            Room room = RoomFactory.createRoom(roomType);
            if (room == null) {
                // Attempt to create a new room if room creation failed
                int newRoomNumber = addRoomToDatabaseIfNotExist(room);
                if (newRoomNumber == -1) {
                    throw new SQLException("Failed to create a new room");
                } else {
                    roomNumber = newRoomNumber;
                }
            }

            // Create Random IDs for Guest and Reservation Operation
            String guestID = UUID.randomUUID().toString();
            String reservationID = UUID.randomUUID().toString();

            // Connect to database
            conn = DatabaseConnection.getInstance().getConnection();
            conn.setAutoCommit(false); // Enable transaction mode

            // Insert data into the Guests table
            String guestQuery = "INSERT INTO Guests ("
                    + "GuestID, GuestName, GuestPhone, GuestEmail, GuestAddress, GuestCity, GuestNationality, PassportNumber, GuestType, RoomNumber, CheckInDate, CheckOutDate, NumberOfDaysOfStayInRoom, Fees)"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            stmtGuest = conn.prepareStatement(guestQuery);
            stmtGuest.setString(1, guestID);
            stmtGuest.setString(2, guestName);
            stmtGuest.setString(3, guestPhone);
            stmtGuest.setString(4, guestEmail);
            stmtGuest.setString(5, guestAddress);
            stmtGuest.setString(6, guestCity);
            stmtGuest.setString(7, guestNationality);
            stmtGuest.setString(8, passportNumber);
            stmtGuest.setString(9, guestType);
            stmtGuest.setInt(10, roomNumber);
            stmtGuest.setDate(11, checkInDate);
            stmtGuest.setDate(12, checkOutDate);
            stmtGuest.setInt(13, numberOfNights);
            stmtGuest.setDouble(14, fees);
            stmtGuest.executeUpdate();

            // Insert room reservation data into the Rooms table
            String roomQuery = "INSERT INTO Rooms ("
                    + "RoomNumber, RoomType, RoomCapacity, NumberResvrNight, CheckInDate, CheckOutDate) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";
            stmtRoom = conn.prepareStatement(roomQuery);
            stmtRoom.setInt(1, roomNumber);
            stmtRoom.setString(2, roomType);
            stmtRoom.setInt(3, roomCapacity);
            stmtRoom.setInt(4, numberOfNights);
            stmtRoom.setDate(5, checkInDate);
            stmtRoom.setDate(6, checkOutDate);
            stmtRoom.executeUpdate();

            // Insert reservation data into the Reservations table
            String reservationQuery = "INSERT INTO Reservations ("
                    + "ReservationID, GuestID, RoomNumber, CheckInDate, CheckOutDate, ReservationDate, NumberOfNights, TotalPrice) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            stmtReservation = conn.prepareStatement(reservationQuery);
            stmtReservation.setString(1, reservationID);
            stmtReservation.setString(2, guestID);
            stmtReservation.setInt(3, roomNumber);
            stmtReservation.setDate(4, checkInDate);
            stmtReservation.setDate(5, checkOutDate);
            stmtReservation.setDate(6, reservationDate);
            stmtReservation.setInt(7, numberOfNights);
            stmtReservation.setDouble(8, fees);
            stmtReservation.executeUpdate();
             
            // 1. Update availability status in the Rooms table
            String updateRoomsAvailabilityQuery = "UPDATE Rooms SET Availability = false WHERE RoomNumber = ?";
            PreparedStatement stmtUpdateRoomAvailability = conn.prepareStatement(updateRoomsAvailabilityQuery);
            stmtUpdateRoomAvailability.setInt(1, roomNumber);
            stmtUpdateRoomAvailability.executeUpdate();

            // 2. Update availability and dates in the RoomsInformation table
            String updateRoomInformationQuery = "UPDATE RoomsInformation SET RoomStates = false, CheckInDate = ?, CheckOutDate = ? WHERE RoomNumber = ?";
            PreparedStatement stmtUpdateRoomInformation = conn.prepareStatement(updateRoomInformationQuery);
            stmtUpdateRoomInformation.setDate(1, checkInDate);
            stmtUpdateRoomInformation.setDate(2, checkOutDate);
            stmtUpdateRoomInformation.setInt(3, roomNumber);
            stmtUpdateRoomInformation.executeUpdate();

            // Commit changes
            conn.commit();
            return true;

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback on error
                } catch (SQLException ex) {
                }
            }
            return false;

        } finally {
            try {
                if (stmtGuest != null) stmtGuest.close();
                if (stmtRoom != null) stmtRoom.close();
                if (stmtReservation != null) stmtReservation.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
            }
        }
    }   
}




