/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//*********************************************************************************************************
    //*********************************************************************************************************
    //***********************************//          Login page           //************************************
    //*********************************************************************************************************
    //************************************************//      Eng: Abd-Alrahman Hassan Al-Khatib     //********
    //********************************************************************************************************* 
package hotel.reservation.management.system;

import java.awt.*;
import java.sql.*;
import javax.swing.*;

/**
 *
 * @author Eng. Abdelrahman
 */
public class Login extends javax.swing.JFrame {

    /**
     * Creates new form Login
     */
     
    //*********************************************************************************************************
    //*********************************************************************************************************
    //***************//A custom Function to set Properties for Label and Buttons in Login page //***************
    //*********************************************************************************************************
    //*********************************************************************************************************
    
    private void setButtonProperties(JButton button, String text, String iconPath, int fontSize) {
                // Loading The Icons
                ImageIcon icon = new ImageIcon(iconPath);
                Image img = icon.getImage();
                Image resizedImg = img.getScaledInstance(20, 20, java.awt.Image.SCALE_SMOOTH);

                // Set Icon and other properties
                button.setIcon(new ImageIcon(resizedImg)); //Add text next to the icon
                button.setText(text);
                
                // Sepecify text and icon style based on orientation
                    button.setFont(new Font("Arial", Font.PLAIN, fontSize));
                    button.setHorizontalTextPosition(SwingConstants.RIGHT); // Text right of icon.
                    button.setVerticalTextPosition(SwingConstants.CENTER); // The icon and text in the middle are vertical.
                    button.setBackground(new java.awt.Color(0, 122, 204)); // Change background color
                    button.setForeground(Color.WHITE); 
                }
     private void setLabelProperties(JLabel label, String text, String iconPath, int fontSize, int iconWidth, int iconHeight){
                //Loading The Icone
                ImageIcon icon =new ImageIcon(iconPath);
                Image img = icon.getImage();
                Image resizedImg = img.getScaledInstance(iconWidth, iconHeight, java.awt.Image.SCALE_SMOOTH);

                //Set Icon and other properties
                label.setIcon(new ImageIcon(resizedImg));
                label.setText(text);
                label.setFont(new Font("Arial", Font.PLAIN, fontSize));
                label.setHorizontalAlignment(SwingConstants.CENTER);
                label.setVerticalTextPosition(SwingConstants.CENTER);
                
    }
     //*******************************************************************//
     //*******************************************************************//
     //          This Method sets the window display properties.         //
     //*******************************************************************//
     //*******************************************************************//
  private void customizeFrameAppearance() {
        //Change the frame
        this.getContentPane().setBackground(new java.awt.Color(240, 240, 240)); 
        
        //Change frame size
        this.setSize(400, 300);
        
        // Change frame address
        this.setTitle("Hotel Management - Login");
        
        // Change the Frame Icon
        ImageIcon appIcon = new ImageIcon("src/images/app_icon.png"); 
        this.setIconImage(appIcon.getImage());
  }
    
    public Login() {
        customizeFrameAppearance();
        
        initComponents(); 
        setLabelProperties(LoginTextLabel, " Login ", "src/images/login.png",35,60,60);
        setLabelProperties(UsernameLoginLabel, "User Name", "src/images/usernamelogin.png",15,25,25);
        setLabelProperties(PasswordLoginLabel, "Password", "src/images/password.png",15,25,25);
        setButtonProperties(LoginButton, "Login", "src/images/loginkey.png",15);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UsernameLoginLabel = new javax.swing.JLabel();
        PasswordLoginLabel = new javax.swing.JLabel();
        UsernameInput = new javax.swing.JTextField();
        PasswordInput = new javax.swing.JPasswordField();
        LoginButton = new javax.swing.JButton();
        LoginTextLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 0, 153));
        setForeground(new java.awt.Color(153, 0, 255));
        setLocation(new java.awt.Point(400, 150));

        UsernameLoginLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        UsernameLoginLabel.setText("Username");

        PasswordLoginLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        PasswordLoginLabel.setText("Password");

        UsernameInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UsernameInputActionPerformed(evt);
            }
        });

        PasswordInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PasswordInputActionPerformed(evt);
            }
        });

        LoginButton.setText("Login");
        LoginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginButtonActionPerformed(evt);
            }
        });

        LoginTextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LoginTextLabel.setText("Login");
        LoginTextLabel.setToolTipText("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(158, 158, 158)
                .addComponent(LoginTextLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(137, 137, 137)
                        .addComponent(LoginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(UsernameLoginLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(PasswordLoginLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 114, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(UsernameInput)
                            .addComponent(PasswordInput, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(LoginTextLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(UsernameLoginLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(UsernameInput, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(PasswordLoginLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(PasswordInput, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addComponent(LoginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LoginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginButtonActionPerformed
        // Get username from Username Field
       String username = UsernameInput.getText();               
       // Get Password from Password Field           
       String password = new String(this.PasswordInput.getPassword());
               /*   ******************************************************************************
                   |***|                    The following code (try AND catch )               |***|
                   |***| Do verify the validity of data Information Login(username, password).|***|
                   |***| By comparing the entered data with the database tabel                |***|
                    ******************************************************************************
               */
       // Variable to store user type (admin or employee)
       String userType = "";
       try {
           // Create a connection from the DatabaseConnection class
           Connection conn = DatabaseConnection.getInstance().getConnection();
           // First check if the user exists in the admin table
           String query = "SELECT PASSWORD FROM admin WHERE username = ?";
           PreparedStatement stmt = conn.prepareStatement(query);
           stmt.setString(1, username);
           // Execute the query and get the result
           ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
               // User found in the admin table, verify the password
               String realPassword = rs.getString("PASSWORD");
               if (realPassword != null && realPassword.equals(password)) {
                   // User is admin
                   userType = "Admin"; 
               } else {
                   JOptionPane.showMessageDialog(this, "Username or Password entered is Invalid", "Error", JOptionPane.ERROR_MESSAGE);
               }
            } else {
               // User not found in admin table, check in the Receptionist table
               query = "SELECT PASSWORD FROM receptionists WHERE username = ?";
               stmt = conn.prepareStatement(query);
               stmt.setString(1, username);

               rs = stmt.executeQuery();
               if (rs.next()) {
                   // User found in the employees table, verify the password
                   String realPassword = rs.getString("PASSWORD");
                   if (realPassword != null && realPassword.equals(password)) {
                       // User is an employee
                       userType = "Receptionist";
                   } else {
                       JOptionPane.showMessageDialog(this, "Username or Password entered is Invalid", "Error", JOptionPane.ERROR_MESSAGE);
                   }
               } else {
                   // User not found in either table
                   JOptionPane.showMessageDialog(this, "Invalid Username", "Error", JOptionPane.ERROR_MESSAGE);
               }
           }
           // If we have reached here, the user has logged in successfully
           // Opening the Home page and passing userType and username
           Home homePage = new Home(username, userType);  // Pass both username and userType to the Home page
           homePage.setVisible(true);
           // Reload images in Home page
           homePage.reloadImages(); // Show home page

           // Close the login page
           this.dispose();

       } catch (SQLException e) {
           // Handle database errors
           JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
       }                         
    }//GEN-LAST:event_LoginButtonActionPerformed

    private void UsernameInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsernameInputActionPerformed
        // Write the some function to Check validation input
    }//GEN-LAST:event_UsernameInputActionPerformed

    private void PasswordInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasswordInputActionPerformed
        // Write the some function to Check validation input
    }//GEN-LAST:event_PasswordInputActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LoginButton;
    private javax.swing.JLabel LoginTextLabel;
    private javax.swing.JPasswordField PasswordInput;
    private javax.swing.JLabel PasswordLoginLabel;
    private javax.swing.JTextField UsernameInput;
    private javax.swing.JLabel UsernameLoginLabel;
    // End of variables declaration//GEN-END:variables
}
