/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.reservation.management.system;

/**
 *
 * @author Eng. Abdelrahman
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PaymentPage extends JFrame {

    private final JTextField cardHolderNameField;
    private final JTextField cardNumberField;
    private final JTextField expiryDateField;
    private final JTextField cvvField;
    private final JButton payButton;

    public PaymentPage() {
        setTitle("Payment Page");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(5, 2, 10, 10));

        //  الحقول والعناصر
        add(new JLabel("Card Holder Name:"));
        cardHolderNameField = new JTextField();
        add(cardHolderNameField);

        add(new JLabel("Card Number:"));
        cardNumberField = new JTextField();
        add(cardNumberField);

        add(new JLabel("Expiry Date (MM/YY):"));
        expiryDateField = new JTextField();
        add(expiryDateField);

        add(new JLabel("CVV:"));
        cvvField = new JTextField();
        add(cvvField);

        payButton = new JButton("Pay");
        add(new JLabel()); // مساحة فارغة
        add(payButton);

        // ربط الزر بمعالج الدفع
        payButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handlePayment();
            }
        });
    }

    private void handlePayment() {
        // جمع بيانات البطاقة
        String cardHolderName = cardHolderNameField.getText();
        String cardNumber = cardNumberField.getText();
        String expiryDate = expiryDateField.getText();
        String cvv = cvvField.getText();

        // الاتصال بمعالج الدفع Singleton
        PaymentProcessor processor = PaymentProcessor.getInstance();
        boolean isPaymentSuccessful = processor.processPayment(cardHolderName, cardNumber, expiryDate, cvv);

        // عرض الرسالة بناءً على النتيجة
        if (isPaymentSuccessful) {
            JOptionPane.showMessageDialog(this, "Payment successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
            this.dispose(); // إغلاق الصفحة بعد نجاح الدفع
        } else {
            JOptionPane.showMessageDialog(this, "Payment failed! Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PaymentPage paymentPage = new PaymentPage();
            paymentPage.setVisible(true);
        });
    }
}
