/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.reservation.management.system;

/**
 *
 * @author Eng. Abdelrahman
 */
public class StandardRoom extends Room {
    public StandardRoom() {
        super("Standard", 2, 150.0); 
    }

    public String getDetails() {
        return "Standard Room with basic facilities.";
    }
}
