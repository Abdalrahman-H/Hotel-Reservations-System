/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.reservation.management.system;

/**
 *
 * @author Eng. Abdelrahman
 */
public class PaymentProcessor {

    private static PaymentProcessor instance;

    private PaymentProcessor() {
    }

    public static PaymentProcessor getInstance() {
        if (instance == null) {
            instance = new PaymentProcessor();
        }
        return instance;
    }

    public boolean processPayment(String cardHolderName, String cardNumber, String expiryDate, String cvv) {
        if (cardNumber.length() == 16 && cvv.length() == 3) {
            System.out.println("Processing payment for card: " + cardNumber);
            return true; 
        }
        return false; 
    }
}

