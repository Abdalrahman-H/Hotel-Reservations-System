/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.reservation.management.system;
/**
 *
 * @author Eng. Abdelrahman
 */
public class RoomFactory {
    public static Room createRoom(String roomType) {
        switch (roomType.toLowerCase()) {
            case "standard":
                return new Room("Standard", 1, 50.0); 
            case "deluxe":
                return new Room("Deluxe", 2, 100.0);
            case "suite":
                return new Room("Suite", 3, 200.0);
            default:
                throw new IllegalArgumentException("Unknown room type: " + roomType);
        }
    }
}

