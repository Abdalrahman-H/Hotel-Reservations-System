/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.reservation.management.system;

/**
 *
 * @author Eng. Abdelrahman
 */
    
    public class Room {
    private String type; 
    private int capacity;
    private double pricePerNight;  

    public Room(String type, int capacity, double pricePerNight) {
        this.type = type;
        this.capacity = capacity;
        this.pricePerNight = pricePerNight;
    }

   
    public String getType() {
        return type;
    }

    public int getCapacity() {
        return capacity;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    @Override
    public String toString() {
        return "Room{" +
               "type='" + type + '\'' +
               ", capacity=" + capacity +
               ", pricePerNight=" + pricePerNight +
               '}';
    }
}

