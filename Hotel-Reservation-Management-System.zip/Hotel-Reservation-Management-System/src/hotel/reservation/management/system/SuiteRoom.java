/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.reservation.management.system;

/**
 *
 * @author Eng. Abdelrahman
 */
public class SuiteRoom extends Room {
    public SuiteRoom() {
        super("Suite", 4, 500.0);  
    }

    public String getDetails() {
        return "Suite Room with luxurious facilities and amenities.";
    }
}
